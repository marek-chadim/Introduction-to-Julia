﻿![](Aspose.Words.260d7c68-0cb0-439a-bdfd-f1c364a95d44.001.png)

**JuliaAcademy![](Aspose.Words.260d7c68-0cb0-439a-bdfd-f1c364a95d44.002.png)![](Aspose.Words.260d7c68-0cb0-439a-bdfd-f1c364a95d44.003.png)**

**CERTIFICATE OF COMPLETION**

Awarded To

**Marek Chadim**

COMPLETING THE COURSE:

**Introduction to Julia (for programmers)**

Date: 2024-03-30

**Award No. ![](Aspose.Words.260d7c68-0cb0-439a-bdfd-f1c364a95d44.004.png)**cert\_9z0k7f86 
